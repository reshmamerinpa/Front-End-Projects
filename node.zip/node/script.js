// const array =["a" , "b", "c"];
// array.push("d") // javascript
// const newArray = [...array,"e"] //ES6
// console.log(newArray);

// //JS
// function newfunc(){
//     return 10;
// }

// console.log(newfunc());

// //ES6

// const newFunc =  () => 20;

// console.log(newFunc());

// // ----------node js--------

// const interval = setInterval(() => {
//     console.log("Running");
// }, 1000);


// setTimeout(() => {
//     // console.log("Running2");
//     clearInterval(interval);
// },2000);

// console.log(global);
// console.log(__filename)


// const path = require("path");
//     console.log(path);

// const path = require("path");
// const fs = require("fs");
// console.log(fs);
// 
// console.log(path.join(__dirname,"api","script.js"))

// fs.mkdir(path.join(__dirname, "/api"), {}, (err) => {
//     if (err) throw err;
// });


// ------writefile------

    
// fs.writeFile(path.join(__dirname, "/api", "api.txt"), "username: Debug", (err) => {
//     if(err) throw err;
// });
// or
// const user = "javascript"
    
// fs.writeFile(path.join(__dirname, "/api", "api.txt"), `user name: ${user}`, (err) => {
//     if(err) throw err;
// });


    
// fs.appendFile(path.join(__dirname, "/api", "api.txt"), `\n\t user name: ${user}`, (err) => {
//     if(err) throw err;
// });


// -------------Events----------

// const EventEmitter =require("events");
// const emitter = new EventEmitter();
// emitter.on("message", (data) => {
//     console.log(data.text);
// });
// emitter.on("logout", (data) => {
//     console.log(data.text);
// });
// emitter.emit("message", {text: "user logged"});
// emitter.emit("logout", {text: "user loggout"});


// ----------HTTP------------
 const http = require("http");
 const path = require("path");
 const fs = require("fs");

 http.createServer((req,res) =>{
    res.write("this is node.js");
    console.log(req.url);
    console.log("test")
    res.end();
 }).listen(3001,() => console.log("server is running"));

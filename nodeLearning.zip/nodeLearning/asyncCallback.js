const fs = require('fs');
const { callbackify } = require('util');
fs.readFile('test.txt','utf-8',function(err,data){
    if(err){
        console.error('Error reading file:',err);
        return;
    }
    console.log(data); 
});

// (err,data)=>{} is a callback
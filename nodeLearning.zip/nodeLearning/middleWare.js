// npm install body-parser- 

const express = require('express');
const app = express();
var bodyParser = require('body-parser')

app.use(function(req,res,next){
    console.log('hit on middleware');
    next();
})
app.use(bodyParser.urlencoded())
app.get('/contact',function(req,res){
    // res.send("Hello from Express!");
    res.json("<h1>home</h1>");
    res.status(200);
    // res.end()
});
app.get("/students",(req,res)=> {
    // res.status(404).send("error!");
    // console.log(req.body)
    res.send("students")
});
app.use(bodyParser.json())
app.post("/login",function(req,res) {
    res.send(req.body.name)
});
app.listen(7001,()=> console.log('server running on port 7001'))


//  Express simplifies creating servers and routes.
//  app.get() handles GET requests
//  res.send() sends a response to the client
//  app.listen() starts the server
// var bodyParser = require('body-parser') - to get the body of a request
//  next() only next method will continue the process otherwise it display hit on middleware

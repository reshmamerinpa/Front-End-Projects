// <H> Core Modeules:Files Systems(fs)


// -----write to a file


const fs = require('fs');
fs.writeFile("test.txt","hai how are you",function(error){
  if(error){
    console.log("unable to write");
  }
})

// -----Read form file

var fs = require("fs");
fs.readFile("test.txt","utf8",function(e,data){
    console.log(data);
})

// ---utf8 is used to get content text otherwise it shows buffer value

// console.log("Hiiiii :)");

const add = require('./math');
console.log(add(3,5.5));

// .  module.exports - exposes a function or object to other Files
// .  require() imports it
// .  Helps keep code organized and reusable.


// -----------------------------------------------------------------------------//



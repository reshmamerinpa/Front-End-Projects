//  REST API with Express

const express = require('express');
const app = express();
app.use(express.json());


let users = [];
// Add a user
app.post('users',(req,res) =>{
    users.push(req.body);
    res.send({message: 'user added',users});
});

app.get('users',(req,res)=>{
    res.send(users);
});
app.listen(3000,() => console.log('API running on port 3000'));
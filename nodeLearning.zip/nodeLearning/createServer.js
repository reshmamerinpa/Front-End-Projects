const { createServer } = require('node:http');

const hostname = '127.0.0.1';
const port = 3000;

const server = createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello World');
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});

// or

// server.listen(3000); 


// imports HTTP module from node.js
// {createserver} is destructuring: it directly extracts the createServer function
// hostname: The IP address where the server will run (127.0.0.1)
// port: the port number (3000 in this case)


// createServer() creates a new HTTP server.
// It takes a callback (req, res) which runs every time a request is made.
// req → Incoming request (from browser).
// res → Response object (what server sends back).
// statusCode = 200: Means success (OK).
// setHeader('Content-Type', 'text/plain'): Tells the browser it’s plain text.
// res.end('Hello World'): Sends "Hello World" and closes the connection.

// server.listen(...): Starts the server.
// Parameters --  port: Port number (3000), hostname: Hostname (127.0.0.1).
// Callback: Runs once server is ready.
// console.log(...): Prints the server URL in terminal.
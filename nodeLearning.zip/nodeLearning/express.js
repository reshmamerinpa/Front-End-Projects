// npm install express - Install express framework
// Express.js, commonly referred to as Express, is a minimal and flexible web application framework for Node.js. It simplifies the process of building server-side applications and APIs by providing a robust set of features and tools.

const express = require('express');
const app = express();

app.get('/contact',function(req,res){
    // res.send("Hello from Express!");
    res.json("<h1>home</h1>");
    res.status(200);
    // res.end()
});
app.get("/students",(req,res)=> {
    // res.status(404).send("error!");
    // console.log(req.body)
    res.send("students")
});

app.listen(7000,()=> console.log('server running on port 3000'))


//  Express simplifies creating servers and routes.
//  app.get() handles GET requests
//  res.send() sends a response to the client
//  app.listen() starts the server
// var bodyParser = require('body-parser') - to get the body of a request
 

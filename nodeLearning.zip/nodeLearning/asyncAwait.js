const fs =require('fs').promises;
async function readFile(){
    try {
        const data = await fs.readFile('test.txt', 'utf-8');
        console.log(data);
    } catch(err){
        console.error('Error:',err);
    }
}

readFile();
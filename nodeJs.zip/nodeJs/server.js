// const { createServer } = require('node:http');

// const hostname = '127.0.0.1';
// const port = 3000;

// const server = createServer((req, res) => {
//   res.statusCode = 200;
//   res.setHeader('Content-Type', 'text/plain');
//   res.end('Hello World');
// });

// server.listen(port, hostname, () => {
//   console.log(`Server running at http://${hostname}:${port}/`);
// });
// -----------------end--------------------------------------------------

// 
// listen(3000); //server litsen to a port number to display the message
// ------------------end-------------------------


// ----------------end---------------

// var fs = require("fs");
// fs.writeFile("test.txt","hai how are you",function(error){
//   if(error){
//     console.log("unable to write");
//   }
// })
// appendFile can be used instead of write file to edit text.txt



// var fs = require("fs");
// fs.readFile("test.txt","utf8",function(e,data){
//     console.log(data);
// })

// ---utf8 is used to get content text otherwise it shows buffer value



// var fs = require("fs");
// fs.unlink("test.txt",function(err){
// })

// -----------------------------------------------
// var http = require("http");
// var fs = require("fs");

// http.createServer(function(req,res){

//   fs.readFile('index.html',function(srr,data){
//     res.write(data);
//     res.end();
//   })
// }).listen(3000);
// --------------------------------------

// var url = require("url");
// var result =url.parse("https://www.google.com/about.html?username=abc");
// console.log(result)
// ----------------

var url = require("url");
var http = require("http");
var fs = require("fs");
http.createServer(function(req,res){
  var parsed = url.parse(req.url);
  console.log(parsed)
}).listen(3000);

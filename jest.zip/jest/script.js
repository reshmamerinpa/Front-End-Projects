// function sum (a,b){
//     return a + b;
// }
// module.exports =sum;


function sum (...nums){
    return nums.reduce((a,b)=> a+b,0);
}
module.exports =sum;


const sum = require('../script');

// test ('adds 2 and 3 to get 5', () => {
//     expect(sum(2,3)).toBe(5);
// }); 
test('adds multiple numbers',() =>{
    expect(sum(1,2,3,4)).toBe(10);
});
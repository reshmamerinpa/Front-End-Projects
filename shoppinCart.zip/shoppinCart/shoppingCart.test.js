const { ShoppingCart } = require('./shoppingCart');

test('should add an item to the cart', () => {
  const cart = new ShoppingCart();
  cart.addItem('Apple', 1.00);
  expect(cart.getItems()).toContain('Apple');
});

test('should calculate the total for one item', () => {
  const cart = new ShoppingCart();
  cart.addItem('Apple', 1.00);
  const total = cart.calculateTotal();
  expect(total).toBe(1.00);
});

test('should calculate the total for multiple items', () => {
  const cart = new ShoppingCart();
  cart.addItem('Apple', 1.00);
  cart.addItem('Bread', 2.50);
  const total = cart.calculateTotal();
  expect(total).toBe(3.50);
});

test('should calculate total of an empty cart as 0', () => {
  const cart = new ShoppingCart();
  const total = cart.calculateTotal();
  expect(total).toBe(0);
});

test('should remove an item from the cart', () => {
  const cart = new ShoppingCart();
  cart.addItem('Apple', 1.00);
  cart.removeItem('Apple');
  expect(cart.getItems()).not.toContain('Apple');
  expect(cart.calculateTotal()).toBe(0);
});

test('should throw an error when trying to remove a non-existent item', () => {
  const cart = new ShoppingCart();
  expect(() => cart.removeItem('NonExistentItem')).toThrow('Item not found');
});
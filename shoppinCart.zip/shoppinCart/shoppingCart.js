class ShoppingCart {
  constructor() {
    this.items = [];
  }

  addItem(name, price) {
    this.items.push({ name, price });
  }

  getItems() {
    return this.items.map(item => item.name);
  }

  calculateTotal() {
    return this.items.reduce((total, item) => total + item.price, 0);
  }

  removeItem(name) {
    const itemExists = this.items.some(item => item.name === name);

    if (!itemExists) {
      throw new Error('Item not found');
    }

    this.items = this.items.filter(item => item.name !== name);
  }
}

module.exports = { ShoppingCart };